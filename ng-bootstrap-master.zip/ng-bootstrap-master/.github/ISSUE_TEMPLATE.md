Please remember, the issues forum is __NOT__ for support requests. It is for bugs and feature requests only.
Please read https://github.com/ng-bootstrap/ng-bootstrap/blob/master/CONTRIBUTING.md and search
existing issues (both open and closed) prior to opening any new issue and ensure you follow the instructions therein.

### Bug description:

### Link to minimally-working plunker that reproduces the issue:

You can fork a plunker from one of our [demos](https://ng-bootstrap.github.io/#/components) and use it as a starting point.
Please note that we can _not_ act on bug reports without a minimal reproduction scenario in plunker. Here is why:
https://github.com/ng-bootstrap/ng-bootstrap#you-think-youve-found-a-bug

### Version of Angular, ng-bootstrap, and Bootstrap:

Angular:

ng-bootstrap:

Bootstrap:
