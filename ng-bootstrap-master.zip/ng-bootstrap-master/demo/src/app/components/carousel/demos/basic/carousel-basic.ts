import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-carousel-basic',
  templateUrl: './carousel-basic.html'
})
export class NgbdCarouselBasic {
}
