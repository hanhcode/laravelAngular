export * from './carousel.component';

import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {NgbdSharedModule} from '../../shared';
import {NgbdComponentsSharedModule} from '../shared';
import {NgbdCarousel} from './carousel.component';
import {DEMO_DIRECTIVES} from './demos';

@NgModule({
  imports: [NgbdSharedModule, NgbdComponentsSharedModule],
  exports: [NgbdCarousel],
  declarations: [NgbdCarousel, ...DEMO_DIRECTIVES]
})
export class NgbdCarouselModule {}
