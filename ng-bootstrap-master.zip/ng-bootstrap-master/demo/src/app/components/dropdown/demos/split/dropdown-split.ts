import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-dropdown-split',
  templateUrl: './dropdown-split.html'
})
export class NgbdDropdownSplit {
}
