import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-popover-container',
  templateUrl: './popover-container.html',
  styles: ['.card { padding: 50px 0; text-align: center; overflow:hidden }']
})
export class NgbdPopoverContainer {
}
