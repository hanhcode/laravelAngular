import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-popover-tplcontent',
  templateUrl: './popover-tplcontent.html'
})
export class NgbdPopoverTplcontent {
  name = 'World';
}
