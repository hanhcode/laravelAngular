import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-popover-triggers',
  templateUrl: './popover-triggers.html'
})
export class NgbdPopoverTriggers {
}
