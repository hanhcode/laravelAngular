import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-popover-visibility',
  templateUrl: './popover-visibility.html'
})
export class NgbdPopoverVisibility {

}
