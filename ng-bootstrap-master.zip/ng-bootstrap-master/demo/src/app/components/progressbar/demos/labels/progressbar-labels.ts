import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-progressbar-labels',
  templateUrl: './progressbar-labels.html',
  styles: [`
    ngb-progressbar {
      margin-top: 5rem;
    }
  `]
})
export class NgbdProgressbarLabels {
}
