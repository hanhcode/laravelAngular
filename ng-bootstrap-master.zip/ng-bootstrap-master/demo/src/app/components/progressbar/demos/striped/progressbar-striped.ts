import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-progressbar-striped',
  templateUrl: './progressbar-striped.html'
})
export class NgbdProgressbarStriped {
}
