import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-tooltip-basic',
  templateUrl: './tooltip-basic.html'
})
export class NgbdTooltipBasic {
}
