import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-tooltip-container',
  templateUrl: './tooltip-container.html',
  styles: ['.card { padding: 50px 0; text-align: center; overflow:hidden }']
})
export class NgbdTooltipContainer {
}
