import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-getting-started',
  templateUrl: './getting-started.component.html'
})
export class GettingStarted {}
