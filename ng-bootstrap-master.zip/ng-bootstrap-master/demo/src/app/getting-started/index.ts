export * from './getting-started.component';
