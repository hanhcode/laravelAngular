//a class with doc to extract

/**
 * This is a documented foo
 */
class DocumentedFoo {
  /**
   * the bar
   */
  bar: string;

  /**
   * A getter
   */
  get componentInstance(): any {
  }

  /**
   * some method
   */
  someMethod(): void {}
}
