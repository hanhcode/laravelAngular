/**
 * Some interface
 */
export interface SomeInterface {
  /**
   * does something
   */
  foo(): void;
}
