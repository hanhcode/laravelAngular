//some ts classes but no docs to extract

class Foo {
}

class Bar {
}
