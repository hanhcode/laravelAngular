import {Component} from '@angular/core';

@Component({selector: 'ngb-modal-backdrop', template: '', host: {'class': 'modal-backdrop fade show'}})
export class NgbModalBackdrop {
}
