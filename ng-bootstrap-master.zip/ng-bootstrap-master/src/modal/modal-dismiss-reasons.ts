export enum ModalDismissReasons {
  BACKDROP_CLICK,
  ESC
}
